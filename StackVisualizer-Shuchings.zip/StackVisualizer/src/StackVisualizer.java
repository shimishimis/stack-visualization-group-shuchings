import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class StackVisualizer extends JFrame {

    private ArrayStack stack;
    private JPanel stackPanel;
    private JLabel statusLabel;
    private JTextField inputField;
    private Random random;

    public StackVisualizer() {
        stack = new ArrayStack(10);
        random = new Random();

        setTitle("Stack Visualizer");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Title
        JLabel titleLabel = new JLabel(
            "STACK VISUALIZER",
            SwingConstants.CENTER
        );

        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBorder(
            BorderFactory.createEmptyBorder(15, 10, 15, 10)
        );

        add(titleLabel, BorderLayout.NORTH);

        // Stack display
        stackPanel = new JPanel();
        stackPanel.setLayout(
            new BoxLayout(stackPanel, BoxLayout.Y_AXIS)
        );

        stackPanel.setBackground(Color.WHITE);
        stackPanel.setBorder(
            BorderFactory.createTitledBorder("Stack Elements")
        );

        JScrollPane scrollPane = new JScrollPane(stackPanel);
        add(scrollPane, BorderLayout.CENTER);

        // Input and buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout(5, 5));
        bottomPanel.setBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        );

        JPanel inputPanel = new JPanel(new FlowLayout());

        inputField = new JTextField(10);
        JButton pushButton = new JButton("PUSH");

        inputPanel.add(new JLabel("Enter Number:"));
        inputPanel.add(inputField);
        inputPanel.add(pushButton);

        bottomPanel.add(inputPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 5, 5));

        JButton popButton = new JButton("POP");
        JButton peekButton = new JButton("PEEK");
        JButton clearButton = new JButton("CLEAR");
        JButton checkButton = new JButton("CHECK STACK");
        JButton randomButton = new JButton("RANDOM");

        buttonPanel.add(popButton);
        buttonPanel.add(peekButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(checkButton);
        buttonPanel.add(randomButton);

        bottomPanel.add(buttonPanel, BorderLayout.CENTER);

        // Status label
        statusLabel = new JLabel(
            "Ready. Stack is empty.",
            SwingConstants.CENTER
        );

        statusLabel.setBorder(
            BorderFactory.createEmptyBorder(8, 5, 5, 5)
        );

        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // PUSH button
        pushButton.addActionListener(e -> {
            try {
                int value = Integer.parseInt(
                    inputField.getText().trim()
                );

                if (stack.isFull()) {
                    showMessage("Stack is full!");
                } else {
                    stack.push(value);
                    inputField.setText("");
                    updateStackDisplay();

                    statusLabel.setText(
                        "Pushed " + value + " onto the stack."
                    );
                }

            } catch (NumberFormatException ex) {
                showMessage("Please enter a valid integer.");
            }
        });

        // POP button
        popButton.addActionListener(e -> {
            if (stack.isEmpty()) {
                showMessage("Cannot pop. Stack is empty!");
            } else {
                int value = stack.pop();
                updateStackDisplay();

                statusLabel.setText(
                    "Popped " + value + " from the stack."
                );
            }
        });

        // PEEK button
        peekButton.addActionListener(e -> {
            if (stack.isEmpty()) {
                showMessage("Stack is empty!");
            } else {
                int value = stack.peek();

                statusLabel.setText(
                    "Top element: " + value
                );

                showMessage("Top element is " + value);
            }
        });

        // CLEAR button
        clearButton.addActionListener(e -> {
            stack.clear();
            updateStackDisplay();

            statusLabel.setText("Stack cleared.");
        });

        // CHECK STACK button
        checkButton.addActionListener(e -> {
            if (stack.isEmpty()) {
                showMessage("The stack is empty.");
            } else if (stack.isFull()) {
                showMessage("The stack is full.");
            } else {
                showMessage(
                    "Stack size: " + stack.size()
                    + "\nRemaining spaces: "
                    + (stack.getCapacity() - stack.size())
                );
            }
        });

        // RANDOM button
        randomButton.addActionListener(e -> {
            if (stack.isFull()) {
                showMessage("Stack is full!");
            } else {
                int number = random.nextInt(100) + 1;

                stack.push(number);
                updateStackDisplay();

                statusLabel.setText(
                    "Random number " + number
                    + " pushed onto the stack."
                );
            }
        });

        updateStackDisplay();
    }

    // Updates the visual stack
    private void updateStackDisplay() {
        stackPanel.removeAll();

        if (stack.isEmpty()) {
            JLabel emptyLabel = new JLabel("Stack is empty");

            emptyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            emptyLabel.setBorder(
                BorderFactory.createEmptyBorder(20, 10, 20, 10)
            );

            stackPanel.add(emptyLabel);

        } else {
            for (int i = stack.size() - 1; i >= 0; i--) {
                int value = stack.getElement(i);

                JLabel elementLabel = new JLabel(
                    "       " + value + "       "
                );

                elementLabel.setFont(
                    new Font("Arial", Font.BOLD, 18)
                );

                elementLabel.setOpaque(true);
                elementLabel.setBackground(
                    i == stack.size() - 1
                        ? new Color(144, 238, 144)
                        : new Color(220, 235, 255)
                );

                elementLabel.setBorder(
                    BorderFactory.createLineBorder(Color.BLACK)
                );

                elementLabel.setAlignmentX(
                    Component.CENTER_ALIGNMENT
                );

                elementLabel.setMaximumSize(
                    new Dimension(200, 40)
                );

                elementLabel.setPreferredSize(
                    new Dimension(200, 40)
                );

                stackPanel.add(elementLabel);
                stackPanel.add(Box.createVerticalStrut(5));
            }
        }

        stackPanel.revalidate();
        stackPanel.repaint();
    }

    // Displays a message
    private void showMessage(String message) {
        JOptionPane.showMessageDialog(
            this,
            message,
            "Stack Visualizer",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    // Main method
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StackVisualizer gui = new StackVisualizer();
            gui.setVisible(true);
        });
    }
}